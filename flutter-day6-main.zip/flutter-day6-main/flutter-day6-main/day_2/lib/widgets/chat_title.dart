import 'package:flutter/material.dart';
import '../models/chat_model.dart';

class ChatTile extends StatelessWidget {
  final ChatModel chat;

  const ChatTile({Key? key, required this.chat}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: CircleAvatar(
        backgroundImage: AssetImage('assets/images/me.jpg'), 
      ),
      title: Text(chat.name),
      subtitle: Row(
        children: [
          Icon(
            chat.isActive ? Icons.circle : Icons.circle_outlined,
            color: chat.isActive ? Colors.green : Colors.grey,
            size: 12,
          ),
          SizedBox(width: 5),
          Expanded(child: Text(chat.message)),
        ],
      ),
      trailing: Text(chat.time),
      onTap: () {
        // Navigate to individual chat screen
      },
    );
  }
}
