import 'package:flutter/material.dart';

class ChatScreen extends StatelessWidget {
  final List<Map<String, dynamic>> chats = [
    {'name': 'Salma', 'message': 'Hey, how are you?', 'time': '10:30 AM', 'isActive': true, 'image': 'assets/images/img1.jpg'},
    {'name': 'mexico', 'message': 'Let\'s catch up soon!', 'time': '9:45 AM', 'isActive': false, 'image': 'assets/images/mexico.png'},
    {'name': 'Saad', 'message': 'Where are you?', 'time': '11:30 AM', 'isActive': true, 'image': 'assets/images/img7.png'},
    {'name': 'uk', 'message': 'Are you free tonight?', 'time': 'Thu', 'isActive': true, 'image': 'assets/images/uk.png'},
    {'name': 'mohamed', 'message': 'Let\'s go out!', 'time': 'Wed', 'isActive': false, 'image': 'assets/images/img2.png'},
    {'name': 'shahd', 'message': 'Let\'s go out!', 'time': 'Wed', 'isActive': false, 'image': 'assets/images/img3.jpg'},
    {'name': 'so3ad', 'message': 'Let\'s go out!', 'time': 'Wed', 'isActive': false, 'image': 'assets/images/img4.png'},
    {'name': 'ne3ma', 'message': 'Let\'s go out!', 'time': 'Wed', 'isActive': false, 'image': 'assets/images/img5.png'},
    {'name': 'shrouk', 'message': 'Let\'s go out!', 'time': 'Wed', 'isActive': false, 'image': 'assets/images/img6.jpg'},
    {'name': 'lolo', 'message': 'Let\'s go out!', 'time': 'Wed', 'isActive': false, 'image': 'assets/images/img8.png'},
    {'name': 'scotland', 'message': 'Let\'s go out!', 'time': 'Wed', 'isActive': false, 'image': 'assets/images/scotland.png'},
    {'name': 'south_africa', 'message': 'Let\'s go out!', 'time': 'Wed', 'isActive': false, 'image': 'assets/images/south_africa.png'},
    {'name': 'netherlands', 'message': 'Let\'s go out!', 'time': 'fri', 'isActive': false, 'image': 'assets/images/netherlands.png'}
  ];

  // Updated people data
  final List<Map<String, dynamic>> people = [
    {'name': 'Your Story', 'isActive': true, 'image': 'assets/images/me.jpg'},
    {'name': 'mexico', 'isActive': true, 'image': 'assets/images/mexico.png'},
    {'name': 'mohamed', 'isActive': false, 'image': 'assets/images/img2.png'},
    {'name': 'shrouk', 'isActive': true, 'image': 'assets/images/img6.jpg'},
    {'name': 'lolo', 'isActive': false, 'image': 'assets/images/img8.png'},
    {'name': 'netherlands', 'isActive': true, 'image': 'assets/images/netherlands.png'},
    {'name': 'Saad', 'isActive': false, 'image': 'assets/images/img7.png'},
    {'name': 'ne3ma', 'isActive': false, 'image': 'assets/images/img5.png'},
    {'name': 'scotland', 'isActive': false, 'image': 'assets/images/scotland.png'},
    {'name': 'scotland', 'isActive': false, 'image': 'assets/images/scotland.png'},
    {'name': 'scotland', 'isActive': false, 'image': 'assets/images/scotland.png'},
    {'name': 'scotland', 'isActive': false, 'image': 'assets/images/scotland.png'},
    {'name': 'scotland', 'isActive': false, 'image': 'assets/images/scotland.png'},
    {'name': 'scotland', 'isActive': false, 'image': 'assets/images/scotland.png'},
    {'name': 'scotland', 'isActive': false, 'image': 'assets/images/scotland.png'},
    {'name': 'scotland', 'isActive': false, 'image': 'assets/images/scotland.png'},
    {'name': 'scotland', 'isActive': false, 'image': 'assets/images/scotland.png'},
    {'name': 'scotland', 'isActive': false, 'image': 'assets/images/scotland.png'}
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            CircleAvatar(
              backgroundImage: AssetImage('assets/images/me.jpg'),
              radius: 20,
            ),
            SizedBox(width: 10),
            Text(
              'Messages',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.camera_alt, color: Colors.blue),
            onPressed: () {},
          ),
          IconButton(
            icon: Icon(Icons.edit, color: Colors.blue),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search messages...',
                filled: true,
                fillColor: Colors.grey[200],
                prefixIcon: Icon(Icons.search, color: Colors.grey),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                  borderSide: BorderSide.none,
                ),
                contentPadding: EdgeInsets.symmetric(horizontal: 15, vertical: 12),
              ),
            ),
          ),
          Container(
            height: 100,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: people.length,
              itemBuilder: (context, index) {
                final person = people[index];
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8.0),
                  child: Column(
                    children: [
                      Stack(
                        alignment: Alignment.bottomRight,
                        children: [
                          CircleAvatar(
                            backgroundImage: AssetImage(person['image']),
                            radius: 30,
                          ),
                          if (person['isActive'])
                            CircleAvatar(
                              radius: 8,
                              backgroundColor: Colors.green,
                            ),
                        ],
                      ),
                      SizedBox(height: 5),
                      Text(
                        person['name'],
                        style: TextStyle(fontSize: 12),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: chats.length,
              itemBuilder: (context, index) {
                final chat = chats[index];
                return ListTile(
                  leading: Stack(
                    alignment: Alignment.bottomRight,
                    children: [
                      CircleAvatar(
                        backgroundImage: AssetImage(chat['image']),
                        radius: 20,
                      ),
                      if (chat['isActive'])
                        CircleAvatar(
                          radius: 5,
                          backgroundColor: Colors.green,
                        ),
                    ],
                  ),
                  title: Text(
                    chat['name'],
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Row(
                    children: [
                      Text(
                        chat['message'],
                        style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                      ),
                      SizedBox(width: 8),
                      Text(
                        chat['time'],
                        style: TextStyle(fontSize: 12, color: Colors.grey),
                      ),
                    ],
                  ),
                  onTap: () {},
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
